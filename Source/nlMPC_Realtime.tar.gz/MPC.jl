include("qpOASES.jl")
include("generate_constrain.jl")
include("dynamics.jl")
include("MPCplot.jl")

################################
#    Init Globle Constant
#
#
################################
# constant for MPC controller
times_of_shooting = 20									# multiple shooting
sample_time       = 1/times_of_shooting					# discreatimilize Real time = sample_t*T

# constant for Dynamic model
const mess  	  	 	= 1.0;									# mess
const Jiner 	  		= 1.0;									# Rotate inercial
#const position_freedom		= 1;
const position_freedom	= 3;
#const speed_freedom		= 1;
const speed_freedom		= 2;
#const dim_sample_x 		= 3;									# dim of sample x;
const dim_sample_x 		= 6;#
#const dim_sample_u			= 1;
const dim_sample_u		= 2;
const dim_sample_xu		= dim_sample_x + dim_sample_u
global number_control	= dim_sample_u * times_of_shooting
#const T_position			= 3
const T_position		= 6
# constant only for RK45
const RK45_Tol   = 0.0001;
const RK45_ATol  = 0.000001;
const RK45_hinit = 0.001;

# constant for qpOASES Sover
global nV     = (times_of_shooting + 1) * dim_sample_xu - dim_sample_u  	 	# Number of variables  (times_of_shooting + 1)* dim of sample [x;u] - end u
global nC_dyn = times_of_shooting * dim_sample_x         	    				# Number of constraints  times_of_shooting * dim of sample x;
global nC_neq = nV #times_of_shooting * dim_sample_u								# nonlinear ineq contrains   dim of u +
const nC_eq   = 2 * (position_freedom + speed_freedom) 							# linear eq contrains	 start + end
## constant for obj function "minize x'Hx+g'x"
H							= zeros(nV,nV); 	        						# Hessian matrix
#H[T_position,T_position]	= 1													
g							= zeros(nV);             							# Gradient vector
g[T_position]=1.0;

## constant for constrains
### constant for start state
#const r_0 = 0.0
#const v_0 = 0.0
 rx_0    = 0.0
 ry_0    = 0.0
 Phi_0   = pi/3
 V_0     = 20.0
 Omega_0 = 0.0
### constant for state
 rx_min    = 0
 rx_max    = 80

 ry_min    = 0
 ry_max    = 40

 V_min   = -28.0
 V_max   =  28.0

 Phi_min = -pi
 Phi_max = pi

 Omega_min = -pi/4
 Omega_max = pi/4

 T_min = 0
 T_max = 30

### constant for end state
#const r_T = 1.50
#const v_T = 0.0
 rx_T    = 62.5
 ry_T    = 20
 V_T     = 10.0
 Phi_T	  = -pi/3
 Omega_T = 0.0
### constant for control 
 a_min     = -3.0
 Ang_a_min = -0.1
 a_max     =  3.0
 Ang_a_max =  0.1

################################
#    Init Globle Peremeter
#
#
################################
global start_lbound	= [rx_0;ry_0;V_0;Phi_0;Omega_0]
#start_lbound	= [r_0;v_0]
global end_ubound = [rx_T;ry_T;V_T;Phi_T;Omega_T]
#global end_ubound	= [r_T;v_T]
global control_lbound=Array(Float64,0)
global control_ubound=Array(Float64,0)
for i=1:times_of_shooting
	control_lbound	= [control_lbound;a_min;Ang_a_min]
	control_ubound	= [control_ubound;a_max;Ang_a_max]
#	control_lbound	= [control_lbound;a_min]
#	control_ubound	= [control_ubound;a_max]
end

global state_lbound = Array(Float64,0) 
global state_ubound = Array(Float64,0)
for i=1:times_of_shooting+1
	state_lbound 	= [state_lbound ;rx_min;ry_min;V_min;Phi_min;Omega_min;T_min]
	state_ubound 	= [state_ubound ;rx_max;ry_max;V_max;Phi_max;Omega_max;T_max]
end


global xOpt		= zeros(nV)  									# Optimal solution	
global A		= zeros(nC_dyn+nC_eq+nC_neq,nV)

global lbA		= zeros(nC_dyn+nC_eq+nC_neq)               		# Lower constraints' bound vector
global ubA		= zeros(nC_dyn+nC_eq+nC_neq)					# Upper constraints' bound vector
                 											
global lb	             	   									# Lower bound vector (on variables)
global ub                										# Upper bound vector (on variables)		
global fval

################################
#    Init xOpt
#
#
################################														
xOpt[1:dim_sample_x-1] 				= start_lbound
for i=1:times_of_shooting+1
	xOpt[i*T_position] = 1
end
xOpt[nV-number_control+1:nV]		= control_ubound
#xOpt[times_of_shooting*+dim_sample_x+1:(times_of_shooting+1)*+dim_sample_x-1] 								= end_ubound

#function main()
global times_of_shift = 0;
result=Array(Float64,0,dim_sample_xu)
result=[start_lbound;0;zeros(dim_sample_u)]'# 0 is for parameter T
global S = zeros(nV)
 
for j = 1 : times_of_shooting-1
	lppoo = 2
	if times_of_shift < 2
		lppoo = 5 
	end
	for i = 1 : lppoo
		S = S + xOpt
		A_dyn	= generate_A_dyn();						#generate contrains of dynamic system
		lbA_dyn	= generate_lubA_dyn();
		ubA_dyn	= lbA_dyn;
	
		A_eq	= generate_A_eq();						#generate linear equallity contrains of parameter T and start and end condition
										
		lbA_eq	= generate_lubA_eq(A_eq);				#generate b in Ads = (As - b) =
		ubA_eq	= lbA_eq;

		A_neq 	= generate_A_neq();						#generate linear inequlity contrains of s
		ubA_neq	= generate_ubA_neq(A_neq);				#generate ub in Ads < (As - ub)
		lbA_neq	= generate_lbA_neq(A_neq);				#generate lb in Ads > (As - lb)
	
		#conpose
		A=[A_dyn;A_eq;A_neq];
		lbA=[lbA_dyn;lbA_eq;lbA_neq];
		ubA=[ubA_dyn;ubA_eq;ubA_neq];
		#A_single=[A;-A]
		#ubA_single=[ubA;-lbA]
	
		fval	= QPOASES_JULIA(H,g,A,[],[],lbA,ubA,xOpt,nV,nC_dyn+nC_eq+nC_neq)
#		fval	= QPOASES_JULIA(H,g,A_single,[],[],[],ubA_single,xOpt,nV,nC_dyn+nC_eq+nC_neq)
	end


times_of_shift 	+= 1
Accept_position = S[dim_sample_x+1:2*dim_sample_x]+xOpt[dim_sample_x+1:2*dim_sample_x]
Accept_control  = S[nV-number_control+1:nV-number_control+dim_sample_u] + xOpt[nV-number_control+1:nV-number_control+dim_sample_u]
result			= [result;[Accept_position' Accept_control']]


xOpt= [xOpt[1:(times_of_shooting+1)*dim_sample_x];xOpt[(times_of_shooting+1)*dim_sample_x+dim_sample_u+1:nV]]
S= [S[1:(times_of_shooting+1)*dim_sample_x];S[(times_of_shooting+1)*dim_sample_x+dim_sample_u+1:nV]]

xOpt= xOpt[dim_sample_x+1:length(xOpt)]
S   = S[dim_sample_x+1:length(S)]

times_of_shooting -= 1
number_control = number_control-dim_sample_u

nV	= nV - dim_sample_xu
nC_dyn	= nC_dyn - dim_sample_x
#nC_neq	= nC_neq - dim_sample_u
nC_neq = nC_neq - dim_sample_xu
start_lbound = (result[times_of_shift+1,1:position_freedom+speed_freedom])'
state_lbound = state_lbound[dim_sample_x+1:length(state_lbound)]
state_ubound = state_ubound[dim_sample_x+1:length(state_ubound)]
control_lbound = control_lbound[dim_sample_u+1:length(control_lbound)]
control_ubound = control_ubound[dim_sample_u+1:length(control_ubound)]

end
S = S + xOpt
result[1,T_position]=result[2,T_position] 																	# init time modified
result = [result;[(S[dim_sample_x+1:2*dim_sample_x])' (S[2*dim_sample_x+1:2*dim_sample_x+dim_sample_u])']]		# 
temp = result[:,dim_sample_x+1:dim_sample_x+dim_sample_u]
result[:,dim_sample_x+1:dim_sample_x+dim_sample_u] = [temp[2:size(temp,1),:];zeros(1,dim_sample_u)]

result = [result[2,T_position]*collect(0:sample_time:1) result]# time axis
Graph=plot_all()
#end
#ttmp=writedata()




