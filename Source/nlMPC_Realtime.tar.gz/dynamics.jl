################################
#    Dynamic Model
#
#
################################


#    State Part
#
#
function dyn_f(x)
dotx=Array(Float64,8)					#X
dotx[1]=x[6]*(x[3]*cos(x[4]))			#x
dotx[2]=x[6]*(x[3]*sin(x[4]))			#y
dotx[3]=x[6]*(0+x[7])					#V
dotx[4]=x[6]*(x[5])						#Angle
dotx[5]=x[6]*(0+x[8])					#Omega
dotx[6]=0								#time
dotx[7]=0								#accelerate
dotx[8]=0								#angular accelerate
return dotx
end

function jac_dyn_f(x)
jac_dotx=Array(Float64,8,8)																		#X
jac_dotx[1,:]=[0 0 x[6]*cos(x[4]) x[6]*x[3]*(-sin(x[4])) 0 x[3]*cos(x[4]) 0 0]					#x
jac_dotx[2,:]=[0 0 x[6]*sin(x[4]) x[6]*x[3]*cos(x[4]) 0 x[3]*sin(x[4]) 0 0]						#y
jac_dotx[3,:]=[0 0 0 0 0 x[7] x[6] 0]															#V
jac_dotx[4,:]=[0 0 0 0 x[6] x[5] 0 0]															#Angle
jac_dotx[5,:]=[0 0 0 0 0 x[8] 0 x[6]]															#Omega
jac_dotx[6:8,:]=zeros(3,8)
return jac_dotx
end

################################
#   Differentiation function 
#	Input	--	Output
#	r			v*T
#	v			a*T
#	T			0
#	a			0
function dyn(y)
	return [y[2]*y[3];y[4]*y[3];0;0]
end

################################
#	Jacobian of differential mapping
#	Input	--	Output
#	r			1	T	v	0
#	v			0	0	a	T	
#	T			0	0	0	0
#	a			0	0	0	0
function jac_dyn(y)
	return [0 y[3] y[2] 0;0 0 y[4] y[3];0 0 0 0;0 0 0 0;]
end
